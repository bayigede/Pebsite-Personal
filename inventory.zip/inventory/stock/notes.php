<!DOCTYPE html>
<html lang="en">
<head>
  <title>Notes</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

<?php
session_start();
include_once '../dbconnect.php';

// cek session login
if (!isset($_SESSION['id']) || !isset($_SESSION['user'])) {
    echo "<div class='alert alert-danger'>
            <strong>Error!</strong> Session belum ada, silakan login dulu.
          </div>";
    exit;
}

// ambil data user dari tabel slogin
$id = intval($_SESSION['id']);
$res = mysqli_query($conn,"SELECT * FROM slogin WHERE id = $id");

// ambil data dari form
if (isset($_POST['konten'])) {
    $konten = mysqli_real_escape_string($conn, $_POST['konten']);
    $oleh   = mysqli_real_escape_string($conn, $_SESSION['user']);

    // simpan ke tabel notes
    $update = "INSERT INTO notes (`contents`, `admin`) VALUES ('$konten','$oleh')";
    $hasil  = mysqli_query($conn,$update);

    if ($hasil){
        echo "<div class='alert alert-success'>
                <strong>Berhasil</strong>
              </div>
              <meta http-equiv='refresh' content='1; url=index.php'/>";
    } else {
        echo "<div class='alert alert-warning'>
                <strong>Failed!</strong> ".mysqli_error($conn)."
              </div>
              <meta http-equiv='refresh' content='2; url=index.php'/>";
    }
}
?>

</div>
</body>
</html>