<?php
session_start();
include 'dbconnect.php';

if(isset($_SESSION['role'])){
    header("location:stock");
}

if(isset($_GET['pesan'])){
    if($_GET['pesan'] == "gagal"){
        echo "<script>alert('Username atau Password salah!');</script>";
    }else if($_GET['pesan'] == "logout"){
        echo "<script>alert('Anda berhasil keluar dari sistem');</script>";
    }else if($_GET['pesan'] == "belum_login"){
        echo "<script>alert('Anda harus Login');</script>";
    }else if($_GET['pesan'] == "noaccess"){
        echo "<script>alert('Akses Ditutup');</script>";
    }
}

if(isset($_POST['btn-login']))
{
 $uname = mysqli_real_escape_string($conn,$_POST['username']);
 $upass = mysqli_real_escape_string($conn,md5($_POST['password']));

 $login = mysqli_query($conn,"select * from slogin where username='$uname' and password='$upass';");
 $cek = mysqli_num_rows($login);

 if($cek > 0){
    $data = mysqli_fetch_assoc($login);

    if($data['role']=="stock"){
        $_SESSION['user'] = $data['nickname'];
        $_SESSION['user_login'] = $data['username'];
        $_SESSION['id'] = $data['id'];
        $_SESSION['role'] = "stock";
        header("location:stock");
    } else {
        header("location:index.php?pesan=gagal");
    }
 }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Dulu</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

  <style>
    body, html {
      height: 100%;
      margin: 0;
      font-family: 'Poppins', sans-serif;
      overflow: hidden;
    }

    /* Slideshow background */
    .slideshow {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      overflow: hidden;
    }

    .slideshow img {
      position: absolute;
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0;
      transition: opacity 2s ease-in-out;
    }

    .slideshow img.active {
      opacity: 1;
    }

    /* Glassmorphism login box */
    .login-box {
      width: 350px;
      padding: 30px;
      border-radius: 20px;
      background: rgba(255, 255, 255, 0.15);
      box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      color: #fff;
      text-align: center;
    }

    .login-box h3 {
      margin-bottom: 25px;
      font-weight: bold;
      font-size: 1.5rem;
    }

    .form-control {
      background: rgba(255,255,255,0.2);
      border: none;
      color: #fff;
    }

    .form-control::placeholder {
      color: #ddd;
    }

    .btn-custom {
      background: linear-gradient(135deg, #00c6ff, #0072ff);
      border: none;
      border-radius: 10px;
      color: white;
      font-weight: bold;
      padding: 10px;
      transition: 0.3s;
    }

    .btn-custom:hover {
      background: linear-gradient(135deg, #0072ff, #00c6ff);
    }
  </style>
</head>
<body>

  <!-- Slideshow Background -->
  <div class="slideshow">
    <img src="lol.jpg" class="active">
    <img src="bu.jpg">
    <img src="rek.jpg">
    <img src="num.jpg">
  </div>

  <!-- Login Box -->
  <div class="d-flex justify-content-center align-items-center vh-100">
    <div class="login-box">
      <h3>Login Dulu</h3>
      <form method="post">
        <div class="mb-3">
          <input type="text" class="form-control" placeholder="Username" name="username" required autofocus>
        </div>
        <div class="mb-3">
          <input type="password" class="form-control" placeholder="Password" name="password" required>
        </div>
        <button type="submit" class="btn btn-custom w-100" name="btn-login">Masuk</button>
      </form>
    </div>
  </div>

  <script>
    // Slideshow otomatis
    let slides = document.querySelectorAll(".slideshow img");
    let current = 0;

    function showNextSlide() {
      slides[current].classList.remove("active");
      current = (current + 1) % slides.length;
      slides[current].classList.add("active");
    }

    setInterval(showNextSlide, 3000); // ganti foto tiap 3 detik
  </script>
</body>
</html>